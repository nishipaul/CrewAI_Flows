"""
Azure Content Safety Framework

A comprehensive framework for implementing input and output guardrails using Azure Content Safety APIs.
"""

from .Input_Guardrails.Codes.blocklist import BlocklistManager
from .Input_Guardrails.Codes.main_input import InputGuardrailOrchestrator
from .Output_Guardrails.main_output import OutputGuardrailOrchestrator
from .pipeline import GuardrailPipeline, run_pipeline

__version__ = "1.0.0"
__all__ = [
    "BlocklistManager",
    "InputGuardrailOrchestrator",
    "OutputGuardrailOrchestrator",
    "GuardrailPipeline",
    "run_pipeline"
]

