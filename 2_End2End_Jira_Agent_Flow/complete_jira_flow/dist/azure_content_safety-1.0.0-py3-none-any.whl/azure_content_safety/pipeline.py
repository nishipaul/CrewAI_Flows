"""
GuardrailPipeline - Main pipeline for running input and output guardrails with configuration support.
"""

import os
import json
from typing import Dict, Any, Optional
from datetime import datetime
from pathlib import Path

from .Input_Guardrails.Codes.main_input import InputGuardrailOrchestrator
from .Output_Guardrails.main_output import OutputGuardrailOrchestrator


class GuardrailPipeline:
    """
    Main pipeline class for running input and output guardrails with configuration support.
    
    This class provides a unified interface for:
    - Running input guardrails on user queries
    - Running output guardrails on generated text
    - Managing configuration via JSON files
    - Logging results to files
    """
    
    def __init__(
        self,
        endpoint: Optional[str] = None,
        subscription_key: Optional[str] = None
    ):
        """
        Initialize the GuardrailPipeline.
        
        Args:
            endpoint: Azure endpoint (if None, will be loaded from environment)
            subscription_key: Azure subscription key (if None, will be loaded from environment)
        """
        # Get credentials from parameters or environment
        self.endpoint = endpoint or os.getenv("endpoint") or os.getenv("CONTENT_SAFETY_ENDPOINT")
        self.subscription_key = subscription_key or os.getenv("subscription_key") or os.getenv("CONTENT_SAFETY_KEY")
        
        if not self.endpoint or not self.subscription_key:
            raise ValueError(
                "Azure credentials not found. Please provide endpoint and subscription_key "
                "as parameters or set environment variables: endpoint/CONTENT_SAFETY_ENDPOINT "
                "and subscription_key/CONTENT_SAFETY_KEY"
            )
        
        # Initialize orchestrators (will be created on demand)
        self._input_orchestrator = None
        self._output_orchestrator = None
    
    def _get_input_orchestrator(self) -> InputGuardrailOrchestrator:
        """Get or create input orchestrator."""
        if self._input_orchestrator is None:
            self._input_orchestrator = InputGuardrailOrchestrator(
                endpoint=self.endpoint,
                subscription_key=self.subscription_key
            )
        return self._input_orchestrator
    
    def _get_output_orchestrator(self) -> OutputGuardrailOrchestrator:
        """Get or create output orchestrator."""
        if self._output_orchestrator is None:
            self._output_orchestrator = OutputGuardrailOrchestrator(
                endpoint=self.endpoint,
                subscription_key=self.subscription_key
            )
        return self._output_orchestrator
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from JSON file."""
        with open(config_path, 'r') as f:
            return json.load(f)
    
    def run(
        self,
        config_path: str,
        user_query: Optional[str] = None,
        generated_text: Optional[str] = None,
        username: Optional[str] = None,
        source_documents: Optional[list] = None
    ) -> Dict[str, Any]:
        """
        Run the guardrail pipeline based on configuration.
        
        Args:
            config_path: Path to the JSON configuration file
            user_query: User input text to check (input guardrails)
            generated_text: Generated text to check (output guardrails)
            username: Username for logging (optional)
            source_documents: Source documents for groundedness check (optional)
        
        Returns:
            Dictionary containing results from input and/or output guardrails
        """
        import time
        start_time = time.time()
        
        # Load configuration
        config = self._load_config(config_path)
        
        # Prepare result structure
        result = {
            'query_timestamp': datetime.now().isoformat()
        }
        
        # If username provided, wrap results in username key
        if username:
            result[username] = {
                'input_results': None,
                'output_results': None,
                'total_time_taken': None
            }
            result_container = result[username]
        else:
            result_container = result
            result_container['input_results'] = None
            result_container['output_results'] = None
            result_container['total_time_taken'] = None
        
        # Run input guardrails if user_query provided
        if user_query:
            input_config = config.get('input_orchestrator', {})
            input_orchestrator = self._get_input_orchestrator()
            
            input_results = input_orchestrator.analyze(
                query=user_query,
                functions=input_config.get('functions'),
                execution_mode=input_config.get('execution_mode', 'parallel'),
                content_safety_threshold=input_config.get('content_safety_threshold', 2),
                enable_pii_modify=input_config.get('enable_pii_modify', False),
                keep_categories=input_config.get('keep_categories'),
                blocklist_names=input_config.get('blocklist_names'),
                break_by_blocklist=input_config.get('break_by_blocklist', False)
            )
            
            result_container['input_results'] = input_results
        
        # Run output guardrails if generated_text provided
        if generated_text:
            output_config = config.get('output_orchestrator', {})
            output_orchestrator = self._get_output_orchestrator()
            
            # Use source_documents from parameter or config
            docs = source_documents or output_config.get('source_documents')
            
            output_results = output_orchestrator.analyze(
                generated_text=generated_text,
                source_documents=docs,
                functions=output_config.get('functions'),
                execution_mode=output_config.get('execution_mode', 'parallel'),
                enable_pii_modify=output_config.get('enable_pii_modify', False),
                keep_categories=output_config.get('keep_categories'),
                content_text=output_config.get('content_text'),
                reasoning=output_config.get('reasoning', False)
            )
            
            result_container['output_results'] = output_results
        
        # Calculate total time taken
        total_time = time.time() - start_time
        result_container['total_time_taken'] = total_time
        
        return result
    
    def to_json(self, result: Dict[str, Any], indent: int = 4) -> str:
        """
        Convert result dictionary to formatted JSON string.
        
        Args:
            result: Result dictionary from run()
            indent: Number of spaces for indentation (default: 4)
        
        Returns:
            Formatted JSON string
        """
        return json.dumps(result, indent=indent)
    
    def save_or_append_log(
        self,
        result: Dict[str, Any],
        log_directory: str = "logs"
    ) -> str:
        """
        Save or append result to a log file.
        
        The log file is named based on username and date: {username}_{date}.json
        If no username is found in the result, uses "anonymous".
        
        Args:
            result: Result dictionary from run()
            log_directory: Directory to save log files (default: "logs")
        
        Returns:
            Path to the log file
        """
        # Create log directory if it doesn't exist
        log_dir = Path(log_directory)
        log_dir.mkdir(parents=True, exist_ok=True)
        
        # Extract username from result
        username = None
        for key in result.keys():
            if key != 'query_timestamp' and isinstance(result[key], dict):
                username = key
                break
        
        if not username:
            username = "anonymous"
        
        # Get current date
        current_date = datetime.now().strftime("%Y-%m-%d")
        
        # Create log file name
        log_filename = f"{username}_{current_date}.json"
        log_path = log_dir / log_filename
        
        # Load existing log if it exists
        if log_path.exists():
            with open(log_path, 'r') as f:
                try:
                    existing_logs = json.load(f)
                    if not isinstance(existing_logs, list):
                        existing_logs = [existing_logs]
                except json.JSONDecodeError:
                    existing_logs = []
        else:
            existing_logs = []
        
        # Append new result
        existing_logs.append(result)
        
        # Save to file
        with open(log_path, 'w') as f:
            json.dump(existing_logs, f, indent=4)
        
        return str(log_path)


def run_pipeline(
    config_path: str,
    user_query: Optional[str] = None,
    generated_text: Optional[str] = None,
    username: Optional[str] = None,
    source_documents: Optional[list] = None,
    endpoint: Optional[str] = None,
    subscription_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Convenience function to run the guardrail pipeline.
    
    Args:
        config_path: Path to the JSON configuration file
        user_query: User input text to check (input guardrails)
        generated_text: Generated text to check (output guardrails)
        username: Username for logging (optional)
        source_documents: Source documents for groundedness check (optional)
        endpoint: Azure endpoint (optional, will use environment if not provided)
        subscription_key: Azure subscription key (optional, will use environment if not provided)
    
    Returns:
        Dictionary containing results from input and/or output guardrails
    """
    pipeline = GuardrailPipeline(endpoint=endpoint, subscription_key=subscription_key)
    return pipeline.run(
        config_path=config_path,
        user_query=user_query,
        generated_text=generated_text,
        username=username,
        source_documents=source_documents
    )

