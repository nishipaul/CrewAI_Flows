"""
Azure Content Safety Blocklist Management

This module provides functionality to manage and analyze text using Azure Content Safety blocklists.
It includes:
- Creating blocklists
- Adding items to blocklists
- Listing blocklists and their items
- Deleting blocklists and items
- Analyzing text against blocklists
"""

import json
import requests
import time
from typing import List, Dict, Any, Optional
from azure.ai.contentsafety import ContentSafetyClient
from azure.core.credentials import AzureKeyCredential
from azure.ai.contentsafety.models import AnalyzeTextOptions
from azure.core.exceptions import HttpResponseError


class BlocklistError(Exception):
    """Custom exception for blocklist operations."""
    def __init__(self, code: str, message: str) -> None:
        self.code = code
        self.message = message

    def __repr__(self) -> str:
        return f"BlocklistError(code={self.code}, message={self.message})"


class BlocklistManager:
    """
    Manager class for Azure Content Safety blocklist operations.
    
    This class provides methods to:
    - Create and delete blocklists
    - Add and remove items from blocklists
    - List all blocklists and their items
    - Analyze text against one or more blocklists
    """
    
    def __init__(self, endpoint: str, subscription_key: str, api_version: str = "2024-09-01") -> None:
        """
        Initialize the BlocklistManager.
        
        Args:
            endpoint: Azure Content Safety endpoint URL
            subscription_key: Azure subscription key
            api_version: API version to use (default: "2024-09-01")
            
        Raises:
            ValueError: If endpoint or subscription_key is None or empty
        """
        if not endpoint:
            raise ValueError(
                "endpoint is required. Please provide a valid Azure Content Safety endpoint URL. "
                "You can set it as an environment variable 'endpoint' in your .env file, "
                "or pass it directly to BlocklistManager(endpoint='...', subscription_key='...')"
            )
        if not subscription_key:
            raise ValueError(
                "subscription_key is required. Please provide a valid Azure subscription key. "
                "You can set it as an environment variable 'subscription_key' in your .env file, "
                "or pass it directly to BlocklistManager(endpoint='...', subscription_key='...')"
            )
        
        self.endpoint = endpoint.rstrip('/')  # Remove trailing slash if present
        self.subscription_key = subscription_key
        self.api_version = api_version
        
        # Initialize the Azure Content Safety SDK client for text analysis
        self.client = ContentSafetyClient(endpoint, AzureKeyCredential(subscription_key))
    
    def _build_headers(self) -> Dict[str, str]:
        """Build common headers for API requests."""
        return {
            "Ocp-Apim-Subscription-Key": self.subscription_key,
            "Content-Type": "application/json",
        }
    
    # ==================== Blocklist Management ====================
    
    def create_blocklist(self, blocklist_name: str, description: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new blocklist.
        
        Args:
            blocklist_name: Name of the blocklist to create
            description: Optional description for the blocklist
            
        Returns:
            Dictionary containing the created blocklist details
            
        Raises:
            BlocklistError: If the API request fails
        """
        url = f"{self.endpoint}/contentsafety/text/blocklists/{blocklist_name}?api-version={self.api_version}"
        headers = self._build_headers()
        
        payload = {"description": description or f"Blocklist: {blocklist_name}"}
        
        response = requests.patch(url, headers=headers, data=json.dumps(payload))
        res_content = response.json()
        
        if response.status_code not in (200, 201):
            raise BlocklistError(
                res_content.get("error", {}).get("code", "UnknownError"),
                res_content.get("error", {}).get("message", "Unknown error"),
            )
        
        return res_content
    
    def delete_blocklist(self, blocklist_name: str) -> Dict[str, Any]:
        """
        Delete an existing blocklist.
        
        Args:
            blocklist_name: Name of the blocklist to delete
            
        Returns:
            Dictionary with success status
            
        Raises:
            BlocklistError: If the API request fails
        """
        url = f"{self.endpoint}/contentsafety/text/blocklists/{blocklist_name}?api-version={self.api_version}"
        headers = self._build_headers()
        
        response = requests.delete(url, headers=headers)
        
        if response.status_code == 204:
            return {"success": True, "message": f"Blocklist '{blocklist_name}' deleted successfully"}
        
        res_content = response.json()
        raise BlocklistError(
            res_content.get("error", {}).get("code", "UnknownError"),
            res_content.get("error", {}).get("message", "Unknown error"),
        )
    
    def list_blocklists(self) -> Dict[str, Any]:
        """
        List all blocklists.
        
        Returns:
            Dictionary containing list of all blocklists with their details
            
        Raises:
            BlocklistError: If the API request fails
        """
        url = f"{self.endpoint}/contentsafety/text/blocklists?api-version={self.api_version}"
        headers = self._build_headers()
        
        response = requests.get(url, headers=headers)
        res_content = response.json()
        
        if response.status_code != 200:
            raise BlocklistError(
                res_content.get("error", {}).get("code", "UnknownError"),
                res_content.get("error", {}).get("message", "Unknown error"),
            )
        
        return res_content
    
    def get_blocklist(self, blocklist_name: str) -> Dict[str, Any]:
        """
        Get details of a specific blocklist.
        
        Args:
            blocklist_name: Name of the blocklist to retrieve
            
        Returns:
            Dictionary containing blocklist details
            
        Raises:
            BlocklistError: If the API request fails
        """
        url = f"{self.endpoint}/contentsafety/text/blocklists/{blocklist_name}?api-version={self.api_version}"
        headers = self._build_headers()
        
        response = requests.get(url, headers=headers)
        res_content = response.json()
        
        if response.status_code != 200:
            raise BlocklistError(
                res_content.get("error", {}).get("code", "UnknownError"),
                res_content.get("error", {}).get("message", "Unknown error"),
            )
        
        return res_content
    
    # ==================== Blocklist Items Management ====================
    
    def add_blocklist_items(
        self,
        blocklist_name: str,
        items: List[str],
        descriptions: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Add items to a blocklist.
        
        Args:
            blocklist_name: Name of the blocklist to add items to
            items: List of text items to add to the blocklist
            descriptions: Optional list of descriptions for each item (must match items length)
            
        Returns:
            Dictionary containing the added items with their IDs
            
        Raises:
            BlocklistError: If the API request fails
            ValueError: If descriptions length doesn't match items length
        """
        if descriptions and len(descriptions) != len(items):
            raise ValueError("Length of descriptions must match length of items")
        
        url = f"{self.endpoint}/contentsafety/text/blocklists/{blocklist_name}:addOrUpdateBlocklistItems?api-version={self.api_version}"
        headers = self._build_headers()
        
        # Build blocklist items
        blocklist_items = []
        for i, item in enumerate(items):
            item_dict = {"text": item}
            if descriptions:
                item_dict["description"] = descriptions[i]
            blocklist_items.append(item_dict)
        
        payload = {"blocklistItems": blocklist_items}
        
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        res_content = response.json()
        
        if response.status_code not in (200, 201):
            raise BlocklistError(
                res_content.get("error", {}).get("code", "UnknownError"),
                res_content.get("error", {}).get("message", "Unknown error"),
            )
        
        return res_content
    
    def remove_blocklist_items(self, blocklist_name: str, item_ids: List[str]) -> Dict[str, Any]:
        """
        Remove items from a blocklist by their IDs.
        
        Args:
            blocklist_name: Name of the blocklist to remove items from
            item_ids: List of item IDs to remove
            
        Returns:
            Dictionary with success status
            
        Raises:
            BlocklistError: If the API request fails
        """
        url = f"{self.endpoint}/contentsafety/text/blocklists/{blocklist_name}:removeBlocklistItems?api-version={self.api_version}"
        headers = self._build_headers()
        
        payload = {"blocklistItemIds": item_ids}
        
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        
        if response.status_code == 204:
            return {"success": True, "message": f"Items removed successfully from blocklist '{blocklist_name}'"}
        
        res_content = response.json()
        raise BlocklistError(
            res_content.get("error", {}).get("code", "UnknownError"),
            res_content.get("error", {}).get("message", "Unknown error"),
        )
    
    def remove_blocklist_items_by_text(
        self,
        blocklist_name: str,
        item_texts: List[str],
        case_sensitive: bool = False
    ) -> Dict[str, Any]:
        """
        Remove items from a blocklist by their text content (user-friendly method).
        
        This method automatically finds the item IDs for the given text and removes them.
        If any text is not found, it will list all available items to help the user.
        
        Args:
            blocklist_name: Name of the blocklist to remove items from
            item_texts: List of item texts to remove (e.g., ["terrible", "crap"])
            case_sensitive: Whether to match text case-sensitively (default: False)
            
        Returns:
            Dictionary with success status, removed items, and not found items
            
        Raises:
            BlocklistError: If the API request fails
            
        Example:
            >>> # Remove items by their text
            >>> result = blocklist_manager.remove_blocklist_items_by_text(
            ...     blocklist_name="strong_words",
            ...     item_texts=["terrible", "crap"]
            ... )
            >>> print(result['removed_count'])  # Number of items removed
        """
        # Get all items in the blocklist
        try:
            items_result = self.list_blocklist_items(blocklist_name)
            all_items = items_result.get('value', [])
        except BlocklistError as e:
            raise BlocklistError(
                e.code,
                f"Failed to list items in blocklist '{blocklist_name}': {e.message}"
            )
        
        if not all_items:
            return {
                "success": False,
                "message": f"Blocklist '{blocklist_name}' is empty",
                "removed_count": 0,
                "not_found": item_texts,
                "available_items": []
            }
        
        # Build a mapping of text to item ID
        text_to_id = {}
        for item in all_items:
            item_text = item.get('text', '')
            item_id = item.get('blocklistItemId', '')
            
            if case_sensitive:
                text_to_id[item_text] = item_id
            else:
                text_to_id[item_text.lower()] = item_id
        
        # Find IDs for the requested texts
        item_ids_to_remove = []
        removed_items = []
        not_found = []
        
        for text in item_texts:
            search_text = text if case_sensitive else text.lower()
            
            if search_text in text_to_id:
                item_id = text_to_id[search_text]
                item_ids_to_remove.append(item_id)
                removed_items.append({
                    "text": text,
                    "item_id": item_id
                })
            else:
                not_found.append(text)
        
        # If some items were not found, provide helpful information
        if not_found:
            available_texts = [item.get('text', '') for item in all_items]
            
            if not item_ids_to_remove:
                # None of the requested items were found
                return {
                    "success": False,
                    "message": f"None of the requested items were found in blocklist '{blocklist_name}'",
                    "removed_count": 0,
                    "not_found": not_found,
                    "available_items": available_texts,
                    "suggestion": f"Available items to remove: {', '.join(available_texts)}"
                }
            else:
                # Some items found, some not found - proceed with partial removal
                print(f"⚠️  Warning: {len(not_found)} item(s) not found: {', '.join(not_found)}")
                print(f"Available items in blocklist: {', '.join(available_texts)}")
        
        # Remove the found items
        if item_ids_to_remove:
            try:
                remove_result = self.remove_blocklist_items(blocklist_name, item_ids_to_remove)
                
                return {
                    "success": True,
                    "message": remove_result.get('message', 'Items removed successfully'),
                    "removed_count": len(item_ids_to_remove),
                    "removed_items": removed_items,
                    "not_found": not_found,
                    "available_items": [item.get('text', '') for item in all_items] if not_found else []
                }
            except BlocklistError as e:
                raise BlocklistError(
                    e.code,
                    f"Failed to remove items: {e.message}"
                )
        
        return {
            "success": False,
            "message": "No items to remove",
            "removed_count": 0,
            "not_found": not_found,
            "available_items": [item.get('text', '') for item in all_items]
        }
    
    def list_blocklist_items(self, blocklist_name: str) -> Dict[str, Any]:
        """
        List all items in a specific blocklist.
        
        Args:
            blocklist_name: Name of the blocklist to list items from
            
        Returns:
            Dictionary containing list of all items in the blocklist
            
        Raises:
            BlocklistError: If the API request fails
        """
        url = f"{self.endpoint}/contentsafety/text/blocklists/{blocklist_name}/blocklistItems?api-version={self.api_version}"
        headers = self._build_headers()
        
        response = requests.get(url, headers=headers)
        res_content = response.json()
        
        if response.status_code != 200:
            raise BlocklistError(
                res_content.get("error", {}).get("code", "UnknownError"),
                res_content.get("error", {}).get("message", "Unknown error"),
            )
        
        return res_content
    
    def get_blocklist_item(self, blocklist_name: str, item_id: str) -> Dict[str, Any]:
        """
        Get details of a specific item in a blocklist.
        
        Args:
            blocklist_name: Name of the blocklist
            item_id: ID of the item to retrieve
            
        Returns:
            Dictionary containing item details
            
        Raises:
            BlocklistError: If the API request fails
        """
        url = f"{self.endpoint}/contentsafety/text/blocklists/{blocklist_name}/blocklistItems/{item_id}?api-version={self.api_version}"
        headers = self._build_headers()
        
        response = requests.get(url, headers=headers)
        res_content = response.json()
        
        if response.status_code != 200:
            raise BlocklistError(
                res_content.get("error", {}).get("code", "UnknownError"),
                res_content.get("error", {}).get("message", "Unknown error"),
            )
        
        return res_content
    
    # ==================== Text Analysis with Blocklist ====================
    
    def analyze_text_with_blocklist(
        self,
        text: str,
        blocklist_names: Optional[List[str]] = None,
        break_by_blocklist: bool = False
    ) -> Dict[str, Any]:
        """
        Analyze text against one or more blocklists using Azure Content Safety SDK.
        
        Args:
            text: Text to analyze
            blocklist_names: List of blocklist names to check against.
                           If None, will use all available blocklists.
            break_by_blocklist: If True, stops at first match. If False, checks all blocklists.
            
        Returns:
            Dictionary containing analysis results with matched blocklist items
            
        Raises:
            BlocklistError: If the API request fails
            
        Note:
            After editing your blocklist, it usually takes effect in 5 minutes.
            Please wait some time before analyzing with blocklist after editing.
        """
        start_time = time.time()
        
        # If no blocklist names provided, get all available blocklists
        if blocklist_names is None:
            try:
                all_blocklists = self.list_blocklists()
                blocklist_names = [bl.get("blocklistName") for bl in all_blocklists.get("value", [])]
            except Exception as e:
                return {
                    "blocklist_check": {
                        "input_text": text,
                        "blocklist_detected": False,
                        "matched_items": [],
                        "blocklists_checked": [],
                        "time_taken": time.time() - start_time,
                        "error": f"Failed to list blocklists: {str(e)}"
                    }
                }
            
            if not blocklist_names:
                return {
                    "blocklist_check": {
                        "input_text": text,
                        "blocklist_detected": False,
                        "matched_items": [],
                        "blocklists_checked": [],
                        "time_taken": time.time() - start_time,
                        "message": "No blocklists available"
                    }
                }
        
        try:
            # Use Azure SDK for text analysis with blocklist
            request = AnalyzeTextOptions(
                text=text,
                blocklist_names=blocklist_names,
                halt_on_blocklist_hit=break_by_blocklist
            )
            
            analysis_result = self.client.analyze_text(request)
            end_time = time.time()
            
            # Extract blocklist matches
            matched_items = []
            
            if analysis_result and analysis_result.blocklists_match:
                for match_result in analysis_result.blocklists_match:
                    matched_items.append({
                        "blocklist_name": match_result.blocklist_name,
                        "item_id": match_result.blocklist_item_id,
                        "item_text": match_result.blocklist_item_text,
                        "offset": getattr(match_result, 'offset', None),
                        "length": getattr(match_result, 'length', None)
                    })
            
            blocklist_detected = len(matched_items) > 0
            
            result = {
                "blocklist_check": {
                    "input_text": text,
                    "blocklist_detected": blocklist_detected,
                    "matched_items": matched_items,
                    "matched_count": len(matched_items),
                    "blocklists_checked": blocklist_names,
                    "break_by_blocklist": break_by_blocklist,
                    "time_taken": end_time - start_time
                }
            }
            
            return result
            
        except HttpResponseError as e:
            error_code = e.error.code if e.error else "UnknownError"
            error_message = e.error.message if e.error else str(e)
            raise BlocklistError(error_code, error_message)
        except Exception as e:
            raise BlocklistError("AnalysisError", f"Failed to analyze text: {str(e)}")
    
    # ==================== Convenience Methods ====================
    
    def get_all_blocklists_with_items(self) -> Dict[str, Any]:
        """
        Get all blocklists along with their items.
        
        Returns:
            Dictionary containing all blocklists with their items
        """
        blocklists = self.list_blocklists()
        
        result = {
            "blocklists": []
        }
        
        for blocklist in blocklists.get("value", []):
            blocklist_name = blocklist.get("blocklistName")
            try:
                items = self.list_blocklist_items(blocklist_name)
                blocklist["items"] = items.get("value", [])
            except BlocklistError:
                blocklist["items"] = []
            
            result["blocklists"].append(blocklist)
        
        return result



