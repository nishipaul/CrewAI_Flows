# Azure Content Safety Framework

A comprehensive Python framework for implementing input and output guardrails using Azure Content Safety APIs.

## Features

- **Input Guardrails**: Content safety, sentiment analysis, PII detection, prompt injection detection, and custom blocklists
- **Output Guardrails**: PII detection with optional redaction, and groundedness checking
- **Blocklist Management**: Create, manage, and analyze text against custom word/phrase blocklists
- **Flexible Configuration**: JSON-based configuration for easy customization
- **Parallel/Sequential Execution**: Choose execution mode based on your needs
- **Async Support**: Full async/await support for modern Python applications
- **Logging**: Automatic log file management with username and date-based organization

## Installation

```bash
pip install azure-content-safety
```

Or install from wheel file:

```bash
pip install azure_content_safety-1.0.0-py3-none-any.whl
```

## Quick Start

### 1. Set Environment Variables

```bash
export endpoint="https://your-resource.cognitiveservices.azure.com/"
export subscription_key="your_subscription_key_here"
```

Or create a `.env` file:

```
endpoint=https://your-resource.cognitiveservices.azure.com/
subscription_key=your_subscription_key_here
```

### 2. Create Configuration File (config.json)

```json
{
    "input_orchestrator": {
        "functions": ["content_safety", "sentiment_check", "pii_check", "prompt_injection", "blocklist_check"],
        "execution_mode": "parallel",
        "content_safety_threshold": 2,
        "enable_pii_modify": false,
        "keep_categories": null,
        "blocklist_names": null,
        "break_by_blocklist": false
    },
    "output_orchestrator": {
        "functions": ["pii_check", "groundedness_check"],
        "execution_mode": "parallel",
        "source_documents": null,
        "enable_pii_modify": false,
        "keep_categories": null,
        "content_text": null,
        "reasoning": false
    }
}
```

### 3. Use the Framework

```python
from azure_content_safety import GuardrailPipeline

# Initialize pipeline
pipeline = GuardrailPipeline()

# Run with config file
result = pipeline.run(
    config_path="config.json",
    user_query="User input text",
    generated_text="Generated response text",
    username="myuser"
)

# Get JSON output
json_output = pipeline.to_json(result)
print(json_output)

# Save to log file
log_path = pipeline.save_or_append_log(result, log_directory="logs")
print(f"Log saved to: {log_path}")
```

## Usage Examples

### Input Only

```python
from azure_content_safety import GuardrailPipeline

pipeline = GuardrailPipeline()
result = pipeline.run(
    config_path="config.json",
    user_query="User input to check"
)
```

### Output Only

```python
from azure_content_safety import GuardrailPipeline

pipeline = GuardrailPipeline()
result = pipeline.run(
    config_path="config.json",
    generated_text="Generated response to check"
)
```

### Both Input and Output

```python
from azure_content_safety import GuardrailPipeline

pipeline = GuardrailPipeline()
result = pipeline.run(
    config_path="config.json",
    user_query="User input",
    generated_text="Generated response",
    username="myuser"
)
```

### Using Convenience Function

```python
from azure_content_safety import run_pipeline

result = run_pipeline(
    config_path="config.json",
    user_query="User input",
    generated_text="Generated response"
)
```

## Blocklist Feature

The framework includes a comprehensive blocklist feature for custom content moderation. You can:

- Create and manage custom blocklists
- Add/remove items from blocklists
- Analyze text against one or more blocklists
- Use blocklists through the config-based pipeline or directly

### Quick Blocklist Example

```python
from azure_content_safety.Input_Guardrails.Codes.blocklist import BlocklistManager
import os

# Initialize
blocklist_manager = BlocklistManager(
    endpoint=os.getenv("endpoint"),
    subscription_key=os.getenv("subscription_key")
)

# Create a blocklist
blocklist_manager.create_blocklist("profanity_list", "List of profane words")

# Add items
blocklist_manager.add_blocklist_items(
    blocklist_name="profanity_list",
    items=["badword1", "badword2"],
    descriptions=["Bad word 1", "Bad word 2"]
)

# Analyze text
result = blocklist_manager.analyze_text_with_blocklist(
    text="Check this text for badword1",
    blocklist_names=["profanity_list"]
)
```

For detailed blocklist documentation, see `Input_Guardrails/Codes/BLOCKLIST_README.md`.

## Configuration Options

See the README files in `Input_Guardrails/Codes/` and `Output_Guardrails/` for detailed configuration options.

## Requirements

- Python 3.8+
- azure-ai-textanalytics>=5.3.0
- azure-ai-contentsafety>=1.0.0
- azure-core>=1.29.0
- python-dotenv>=1.0.0
- requests>=2.31.0

## License

MIT License

## Support

For issues and questions, please open an issue on GitHub.

